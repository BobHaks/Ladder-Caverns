import pygame
import random
import os
import tkinter as tk
from tkinter import messagebox

# Constants
GAME_WIDTH, GAME_HEIGHT = 640, 720
WINDOW_WIDTH, WINDOW_HEIGHT = 960, 720
TILE_SIZE = 32
FPS = 60

# Initialize pygame
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load(os.path.join("game", "music.ogg"))
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Ladder Caverns")
clock = pygame.time.Clock()

ASSET_PATH = os.path.join("game")

def crash_report(e):
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Game Crash", str(e))
    root.destroy()

def load_image(name):
    full_path = os.path.join(ASSET_PATH, name + ".gif")
    if not os.path.exists(full_path):
        raise FileNotFoundError(f"Missing file: {full_path}")
    return pygame.transform.scale(pygame.image.load(full_path), (TILE_SIZE, TILE_SIZE))

ASSETS = {
    "player": load_image("player"),
    "floor": load_image("floor"),
    "slime": load_image("slime"),
    "ghost": load_image("ghost"),
    "golem": load_image("golem"),
    "ladder": load_image("ladder"),
    "pickaxe": load_image("pickaxe")
}

class Entity(pygame.sprite.Sprite):
    def __init__(self, image, x, y):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(topleft=(x, y))

class Player(Entity):
    def __init__(self, x, y):
        super().__init__(ASSETS["player"], x, y)
        self.speed = 4
        self.health = 100
        self.score = 0

    def update(self, keys):
        if keys[pygame.K_LEFT]: self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]: self.rect.x += self.speed
        if keys[pygame.K_UP]: self.rect.y -= self.speed
        if keys[pygame.K_DOWN]: self.rect.y += self.speed
        self.stay_in_bounds()

    def stay_in_bounds(self):
        self.rect.x = max(0, min(GAME_WIDTH - TILE_SIZE, self.rect.x))
        self.rect.y = max(0, min(GAME_HEIGHT - TILE_SIZE, self.rect.y))

    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            self.show_game_over_screen()

    def show_game_over_screen(self):
        font = pygame.font.SysFont(None, 48)
        text = font.render("YOU DIED", True, (255, 0, 0))
        screen.fill((0, 0, 0))
        screen.blit(text, (WINDOW_WIDTH // 2 - text.get_width() // 2, WINDOW_HEIGHT // 2 - text.get_height() // 2))

        respawn_button = pygame.Rect(WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 50, 200, 40)
        quit_button = pygame.Rect(WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 100, 200, 40)

        pygame.draw.rect(screen, (0, 255, 0), respawn_button)
        pygame.draw.rect(screen, (255, 0, 0), quit_button)

        font = pygame.font.SysFont(None, 36)
        screen.blit(font.render("Respawn", True, (0, 0, 0)), (respawn_button.centerx - 50, respawn_button.centery - 18))
        screen.blit(font.render("Quit", True, (0, 0, 0)), (quit_button.centerx - 25, quit_button.centery - 18))

        pygame.display.flip()
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if respawn_button.collidepoint(event.pos):
                        self.health = 100
                        self.score = 0
                        self.rect.topleft = (100, 100)
                        generate_level()
                        waiting = False
                    elif quit_button.collidepoint(event.pos):
                        pygame.quit()
                        exit()

class Enemy(Entity):
    def __init__(self, kind, x, y):
        super().__init__(ASSETS[kind], x, y)
        self.health = 3
        self.speed = 1
        self.attack_cooldown = 0

    def update(self, target):
        dx, dy = target.rect.x - self.rect.x, target.rect.y - self.rect.y
        distance = max(abs(dx), abs(dy))

        if distance < 150:
            if abs(dx) > abs(dy):
                self.rect.x += self.speed if dx > 0 else -self.speed
            else:
                self.rect.y += self.speed if dy > 0 else -self.speed

        if self.rect.colliderect(target.rect):
            if self.attack_cooldown == 0:
                target.take_damage(10)
                self.attack_cooldown = FPS * 2
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

class Rock(Entity):
    def __init__(self, x, y):
        super().__init__(ASSETS["pickaxe"], x, y)
        self.health = 2
        self.is_broken = False

    def break_rock(self):
        if self.health <= 0:
            self.is_broken = True

class Ladder(Entity):
    def __init__(self, x, y):
        super().__init__(ASSETS["ladder"], x, y)

# Groups
floor_tiles = pygame.sprite.Group()
enemies = pygame.sprite.Group()
rocks = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
interactive = pygame.sprite.Group()

player = Player(100, 100)
all_sprites.add(player)
floor_positions = set()
level = 1
ladder_spawned = False

def generate_level():
    global ladder_spawned, level
    floor_tiles.empty()
    enemies.empty()
    rocks.empty()
    all_sprites.empty()
    interactive.empty()
    all_sprites.add(player)
    floor_positions.clear()

    for y in range(0, GAME_HEIGHT, TILE_SIZE):
        for x in range(0, GAME_WIDTH, TILE_SIZE):
            floor = Entity(ASSETS["floor"], x, y)
            floor_tiles.add(floor)
            floor_positions.add((x, y))

    occupied = set()
    occupied.add((player.rect.x, player.rect.y))

    def get_random_tile():
        options = list(floor_positions - occupied)
        return random.choice(options) if options else (0, 0)

    for _ in range(5 + level):
        kind = random.choice(["slime", "ghost"])
        x, y = get_random_tile()
        occupied.add((x, y))
        e = Enemy(kind, x, y)
        enemies.add(e)
        all_sprites.add(e)

    for _ in range(4 + level):
        x, y = get_random_tile()
        occupied.add((x, y))
        r = Rock(x, y)
        rocks.add(r)
        all_sprites.add(r)

    player.rect.topleft = (random.randint(0, GAME_WIDTH - TILE_SIZE), random.randint(0, GAME_HEIGHT - TILE_SIZE))
    ladder_spawned = False

def draw_hud():
    font = pygame.font.SysFont(None, 24)
    hp = font.render(f"HP: {player.health}/100", True, (255, 0, 0))
    level_txt = font.render(f"Level: {level}", True, (255, 255, 255))
    score = font.render(f"Score: {player.score}", True, (255, 255, 0))

    controls = ["Arrow keys - Move", "Z - Break Rock", "X - Attack", "Esc - Pause"]
    screen.blit(hp, (10, WINDOW_HEIGHT - 90))
    screen.blit(level_txt, (10, WINDOW_HEIGHT - 60))
    screen.blit(score, (10, WINDOW_HEIGHT - 30))

    for i, text in enumerate(controls):
        txt = font.render(text, True, (200, 200, 200))
        screen.blit(txt, (10, 10 + i * 20))
        screen.blit(txt, (GAME_WIDTH + 20, 10 + i * 20))

paused = False
running = True
generate_level()

while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                paused = not paused
            if event.key == pygame.K_z:
                for rock in rocks:
                    if player.rect.colliderect(rock.rect) and not rock.is_broken:
                        rock.health -= 1
                        if rock.health <= 0:
                            rock.break_rock()
                            player.score += 1
                            rocks.remove(rock)
                            all_sprites.remove(rock)
            if event.key == pygame.K_x:
                for enemy in enemies:
                    if player.rect.colliderect(enemy.rect.inflate(40, 40)):
                        enemy.health -= 1

    if not paused:
        keys = pygame.key.get_pressed()
        player.update(keys)

        for enemy in enemies.copy():
            enemy.update(player)
            if enemy.health <= 0:
                enemies.remove(enemy)
                all_sprites.remove(enemy)
                player.score += 1
                if not ladder_spawned and random.random() < 0.2:
                    ladder = Ladder(enemy.rect.x, enemy.rect.y)
                    interactive.add(ladder)
                    all_sprites.add(ladder)
                    ladder_spawned = True

        for ladder in interactive:
            if player.rect.colliderect(ladder.rect):
                level += 1
                generate_level()

        if not ladder_spawned and len(enemies) == 0 and len(rocks) == 0:
            ladder = Ladder(player.rect.x, player.rect.y)
            interactive.add(ladder)
            all_sprites.add(ladder)
            ladder_spawned = True

    screen.fill((0, 0, 0))
    floor_tiles.draw(screen)
    all_sprites.draw(screen)
    draw_hud()
    pygame.display.flip()

pygame.quit()